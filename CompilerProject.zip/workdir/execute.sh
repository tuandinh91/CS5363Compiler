#!/bin/bash

if [ $# -ne 1 ]; then
    echo $0: usage: myscript name
    exit 1
fi

name=$1

java -cp .. TLCompiler/TLCompiler $name