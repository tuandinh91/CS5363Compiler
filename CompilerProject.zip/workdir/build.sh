#!/bin/bash
javac -cp . ../TLCompiler/*.java